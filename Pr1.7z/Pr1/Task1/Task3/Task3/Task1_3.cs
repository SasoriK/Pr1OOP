﻿using System;

namespace Task3
{
    class Task1_3
    {
        static void Main(string[] args)
        {
            try
            {
                long a = 333000000000;
                long b = 600000000000;
                int c = checked((int)(a + b)); //В int не поместится такое огромное число
                Console.WriteLine(c);
            }
            catch (OverflowException ex) //Поэтому мы и ловим ошибку
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}