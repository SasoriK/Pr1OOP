﻿using System;
// выводим зарплату в зависимости от переданного формата
dynamic ChangeType(dynamic value, string format)
{
    if (format == "string") return value.ToString();
    if (format == "int") return Convert.ToInt32(value);
    if (format == "byte") return Convert.ToByte(value);
    if (format == "char") return Convert.ToChar(value);
    if (format == "float") return (float)(Convert.ToDouble(value));
    if (format == "double") return Convert.ToDouble(value);
    if (format == "decimal") return Convert.ToDecimal(value);
    if (format == "bool") return Convert.ToBoolean(value);
    if (value == "object") return;
    else return 0.0;
}
Console.WriteLine(ChangeType("55", "int"));
Console.WriteLine(ChangeType("55", "int").GetType());
