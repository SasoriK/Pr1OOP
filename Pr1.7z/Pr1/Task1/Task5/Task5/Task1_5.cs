﻿using System;
//5)Пользовательское преобразование типов Implicit, Explicit;
Salary new_salary = new Salary { Rubles = 13400 };
int x = (int)new_salary; //Необходимо явно указать тип
Console.WriteLine($"Явный перевод: {x}");

Salary prev_salary = x;
Console.WriteLine($"Неявный перевод: {prev_salary.Rubles}");
//Класс, хранящий размер зарплаты и хранит ее в рублях в свойстве Rubles
class Salary
{
    public int Rubles { get; set; }
    //Неявное преобразование, число в объект, у которого есть число в свойстве
    public static implicit operator Salary(int x) //Salary - тот тип, во что преобразовываем, в скобках
    //тот тип, что преобразовываем
    {
        return new Salary { Rubles = x };
    }
    //Явное преобразование, позволяет получить число из объекта
    public static explicit operator int(Salary salary)
    {
        return salary.Rubles;
    }
}