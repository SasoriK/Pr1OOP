﻿using System;
//6) Преобразование с помощью класса Convert и преобразование строки в число с помощью методов
//Parse, TryParse класса System.Int32.
namespace Task6
{
    class Task1_6
    {
        static void Main(string[] args)
        {
            int f = 50;
            string conv = f.ToString(); //Число в строку
            conv = "546"; 
            f = int.Parse(conv); //Строку в число при помощи Parse
            conv = Console.ReadLine();
            bool result = int.TryParse(conv, out var number); //Преобразование строки в число TryParse
            if (result == true)
                Console.WriteLine($"Преобразование прошло успешно. Число: {number}");
            else
                Console.WriteLine("Преобразование завершилось неудачно");
            //Преобразование числа в логический тип Convert
            int trut = 2;
            bool d = Convert.ToBoolean(trut);
            Console.WriteLine(d);
        }
    }
}