﻿using System;
//4)Безопасное приведение ссылочных типов с помощью операторов as и is;
//as
Animal animal1 = new Animal("dog");
Pet? beaver = animal1 as Pet; //? указывает что перем. может хранить как значение null так и значение Pet.
if (beaver == null)//Сможем ли мы перевести animal(переменную базового класса) к pet (нет) 
{
    Console.WriteLine("Преобразование прошло неудачно");
}
else
{
    Console.WriteLine(beaver.Type);
}
//В обратную сторону
Pet possum = new Pet("Lola", "Possum");
Animal? an2 = possum as Animal; //Да, мы можем преобразовать переменную производного класса к базовому типу
if (an2 == null)
{
    Console.WriteLine("Преобразование прошло неудачно");
}
else
{
    Console.WriteLine(an2.Name);
}
//is
Animal an3 = new Animal("Crock"); //Переменная базового типа
if (an3 is Pet pet) //Можем ли мы представить ее как переменную производного класса
{
    Console.WriteLine(pet.Type);
}
else
{
    Console.WriteLine("Преобразование не допустимо"); //Не можем
}

class Animal
{
    public string Name { get; set; }
    public Animal(string name)
    {
        Name = name;
    }
    public void Print()
    {
        Console.WriteLine($"Animal {Name}");
    }
}

class Pet : Animal
{
    public string Type { get; set; }
    public Pet(string name, string pet) : base(name)
    {
        Type = pet;
    }
}

class WildAnimal : Animal
{
    public string Habitat { get; set; }
    public WildAnimal(string name, string habitat) : base(name)
    {
        Habitat = habitat;
    }
}