﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task7
{
    public partial class Form1 : Form
    {
        void CheckText()
        {
            int test;
            bool result = double.TryParse(textBox1.Text, out var number); //Преобразование ввода в число
            if (result == true)
            {
                test = (int)number;
                if (number - test != 0) //Если введено было число, и при этом при переводе в int 
                                        //теряется дробная часть, то выводим
                {
                    MessageBox.Show($"Число: {number}");
                }
                else
                    MessageBox.Show("Число не соответсвует установленному формату");
            }
            else
                MessageBox.Show("Число не соответсвует установленному формату");
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Enter_Click(object sender, EventArgs e)
        {
            CheckText();
        }
    }
}