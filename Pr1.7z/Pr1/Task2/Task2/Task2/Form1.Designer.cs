﻿
namespace Task2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.amOfIter = new System.Windows.Forms.Label();
            this.runIteration = new System.Windows.Forms.Button();
            this.fault = new System.Windows.Forms.Label();
            this.RootOnIter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxValue
            // 
            this.textBoxValue.Location = new System.Drawing.Point(32, 26);
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.Size = new System.Drawing.Size(376, 20);
            this.textBoxValue.TabIndex = 0;
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(433, 26);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(94, 44);
            this.Calculate.TabIndex = 1;
            this.Calculate.Text = "Вычислить";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "0.0 (Используя .Net Framework)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "0.0 (Используя метод Ньютона)";
            // 
            // amOfIter
            // 
            this.amOfIter.AutoSize = true;
            this.amOfIter.Location = new System.Drawing.Point(45, 145);
            this.amOfIter.Name = "amOfIter";
            this.amOfIter.Size = new System.Drawing.Size(128, 13);
            this.amOfIter.TabIndex = 4;
            this.amOfIter.Text = "Количество итераций: 0";
            // 
            // runIteration
            // 
            this.runIteration.Location = new System.Drawing.Point(433, 135);
            this.runIteration.Name = "runIteration";
            this.runIteration.Size = new System.Drawing.Size(94, 48);
            this.runIteration.TabIndex = 5;
            this.runIteration.Text = "Выполнить итерацию";
            this.runIteration.UseVisualStyleBackColor = true;
            this.runIteration.Click += new System.EventHandler(this.runIteration_Click);
            // 
            // fault
            // 
            this.fault.AutoSize = true;
            this.fault.Location = new System.Drawing.Point(48, 176);
            this.fault.Name = "fault";
            this.fault.Size = new System.Drawing.Size(75, 13);
            this.fault.TabIndex = 6;
            this.fault.Text = "Погрешность";
            // 
            // RootOnIter
            // 
            this.RootOnIter.AutoSize = true;
            this.RootOnIter.Location = new System.Drawing.Point(48, 210);
            this.RootOnIter.Name = "RootOnIter";
            this.RootOnIter.Size = new System.Drawing.Size(148, 13);
            this.RootOnIter.TabIndex = 7;
            this.RootOnIter.Text = "Корень на данной итерации";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RootOnIter);
            this.Controls.Add(this.fault);
            this.Controls.Add(this.runIteration);
            this.Controls.Add(this.amOfIter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.textBoxValue);
            this.Name = "Form1";
            this.Text = "Вычисление квадратного корня методом Ньютона (Погонялов Даниил, ПИ-б-о 211)";
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Form1_PreviewKeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label amOfIter;
        public System.Windows.Forms.Button runIteration;
        public System.Windows.Forms.TextBox textBoxValue;
        public System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Label fault;
        private System.Windows.Forms.Label RootOnIter;
    }
}

