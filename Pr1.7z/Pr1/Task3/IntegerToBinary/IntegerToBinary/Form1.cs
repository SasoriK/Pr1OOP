﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegerToBinary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Реагирует на нажатие кнопки "Конвертировать"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ConvertButton_Click(object sender, EventArgs e)
        {
            int i;//Хранится значение, введенное в textBox
            int reminder = 0;//Остаток от деления            
            StringBuilder binary = new StringBuilder();//Изменяемая строка символов
            bool result = int.TryParse(intValue.Text, out var number);
            if(result == true)//Проверяем, int ли ввел пользователь
            {
                if(number < 0) //Положительное ли число ввел пользователь
                {
                    MessageBox.Show("Введите положительное число");
                    return;
                }
                else //Если да, то 
                {
                    i = number; //Присваеваем i значение textBox                    
                    do //Выполняем цикл
                    {
                        reminder = i % 2;//Сохраняем остаток
                        i = i / 2;
                        binary.Insert(0, reminder); //Помещаем его в строку
                    } while (i>0); //Задом наперед
                    Result.Text = binary.ToString(); //Выводим результат
                }
            }
            else
            {
                MessageBox.Show("Введите число типа int");
                return;
            }
        }
    }
}
